package com.example.studio_book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudioBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudioBookApplication.class, args);
	}

}
