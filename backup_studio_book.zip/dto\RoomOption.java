// src/main/java/com/example/studio_book/dto/RoomOption.java
package com.example.studio_book.dto;

public record RoomOption(Integer id, String name) {}

